Contains third-party libraries on which JStyx depends.  Newer versions of these
libraries should also work, but have (probably) not been tested.  For the JStyx
library itself, please see the target directory of this distribution.  (If the
JStyx library isn't present, change into the root directory of the distribution
and run "ant jar".)

Jon Blower
July 2005